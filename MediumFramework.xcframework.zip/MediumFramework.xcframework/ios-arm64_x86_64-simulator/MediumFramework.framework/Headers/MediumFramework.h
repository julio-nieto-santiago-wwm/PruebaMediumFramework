//
//  MediumFramework.h
//  MediumFramework
//
//  Created by Julio Nieto Santiago on 25/10/23.
//

#import <Foundation/Foundation.h>

//! Project version number for MediumFramework.
FOUNDATION_EXPORT double MediumFrameworkVersionNumber;

//! Project version string for MediumFramework.
FOUNDATION_EXPORT const unsigned char MediumFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MediumFramework/PublicHeader.h>


